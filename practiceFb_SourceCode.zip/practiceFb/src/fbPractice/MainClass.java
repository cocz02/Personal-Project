package fbPractice;

import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.annotations.Test;

public class MainClass {
	
	@Test
	  public static void main(String[] args) throws InterruptedException {
	
		   ITestNGListener tla = null;
		  TestNG testng = new TestNG();
		  testng.setTestClasses(new Class[] { NewTest.class }); // Enter the name of testNG class which is there in the same package . Else import package.class first .then proceed
		  testng.addListener(tla);
		  testng.run();
		
	  }
	
}
