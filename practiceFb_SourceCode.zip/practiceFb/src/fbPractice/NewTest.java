package fbPractice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import multiScreenShot.MultiScreenShot;

public class NewTest {
	// Fb page URL
    public String baseUrl = "https://facebook.com";
    // Used to initialize FireFox browser
    String driverPath = "C:\\geckodriver\\geckodriver.exe";
    public WebDriver driver ; 
  
    MultiScreenShot screenShot = new MultiScreenShot("C://SampleProject1Screenshot//", "");
    
  @BeforeTest
  public void openBrowser() {
      System.setProperty("webdriver.gecko.driver", driverPath);
      driver = new FirefoxDriver();
      driver.get(baseUrl);
      driver.manage().window().maximize();
  }
  
  // Script for signing up to Facebook
  @Test(priority = 1)
  public void fbSignUp() throws Throwable {
	  driver.findElement(By.xpath("//*[@id=\"u_0_m\"]")).click();
	  WebElement firstName = driver.findElement(By.xpath("//*[@id=\"u_0_m\"]"));
	  firstName.sendKeys("Juan");
	  
	  driver.findElement(By.xpath("//*[@id=\"u_0_o\"]")).click();
	  WebElement lastName = driver.findElement(By.xpath("//*[@id=\"u_0_o\"]"));
	  lastName.sendKeys("Dela Cruz");
	  
	  driver.findElement(By.xpath("//*[@id=\"u_0_r\"]")).click();
	  WebElement mobileEmail = driver.findElement(By.xpath("//*[@id=\"u_0_r\"]"));
	  mobileEmail.sendKeys("juandelacruz@gmail.com");
	  
	  driver.findElement(By.xpath("//*[@id=\"u_0_u\"]")).click();
	  WebElement mobileEmail2 = driver.findElement(By.xpath("//*[@id=\"u_0_u\"]"));
	  mobileEmail2.sendKeys("juandelacruz@gmail.com");
	  
	  driver.findElement(By.xpath("//*[@id=\"password_step_input\"]")).click();
	  WebElement newPass = driver.findElement(By.xpath("//*[@id=\"password_step_input\"]"));
	  newPass.sendKeys("abcd1234");
	  
	  Select month = new Select(driver.findElement(By.id("month")));
	  month.selectByVisibleText("Aug");
	  
	  Select day = new Select(driver.findElement(By.id("day")));
	  day.selectByVisibleText("12");
	  
	  Select year = new Select(driver.findElement(By.id("year")));
	  year.selectByVisibleText("1990");
	  
	  driver.findElement(By.xpath("//*[@id=\"u_0_7\"]")).click(); 
	  
      screenShot.multiScreenShot(driver);
  }
  
  @Test(priority = 2)
  public void fbLogin() throws InterruptedException, Throwable {
	  WebDriverWait wait = new WebDriverWait(driver, 40);
	  
      TimeUnit.SECONDS.sleep(1);
	  // Used to find web element of fb email textbox
      driver.findElement(By.id("email")).click();
      WebElement email = driver.findElement(By.id("email"));
	  // Used to find web element of fb password textbox
      driver.findElement(By.id("pass")).click();
      WebElement password = driver.findElement(By.id("pass"));

      email.sendKeys("choco@gmail.com");
      screenShot.multiScreenShot(driver);
      password.sendKeys("abcd1234");
      screenShot.multiScreenShot(driver);
      
      driver.findElement(By.id("loginbutton")).click();
      
      driver.getPageSource().contains("Wrong Credentials");
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
      screenShot.multiScreenShot(driver);
  }
  
}